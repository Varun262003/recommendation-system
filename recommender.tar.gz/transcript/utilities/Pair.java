package transcript.utilities;

import transcript.data.Entry;

public class Pair {
    public Entry a;
    public Entry b;
    
    public Pair(Entry a, Entry b) {
        this.a = a;
        this.b = b;
    }
}
